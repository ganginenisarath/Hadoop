package com.eng.weblogProject;

import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
//import org.apache.hadoop.util.GenericOptionsParser;
//import java.util.Date;
//import java.util.Formatter;

public class WeblogDriver {

  public static void main(String[] args) throws IOException,
          InterruptedException, ClassNotFoundException {
      Configuration conf = new Configuration();
      conf.set("fs.default.name", "file:///");
      conf.set("mapred.job.tracker", "local");
      conf.set("fs.file.impl", "com.eng.weblogProject.WindowsLocalFileSystem");
      conf.set("io.serializations","org.apache.hadoop.io.serializer.JavaSerialization,"
      + "org.apache.hadoop.io.serializer.WritableSerialization");
      
      Job job = Job.getInstance(conf, "Weblog Analysis");
      job.setJarByClass(WeblogDriver.class);
      
      job.setOutputKeyClass(Text.class);
      job.setOutputValueClass(IntWritable.class);

      job.setMapperClass(WeblogMapper.class);
      job.setNumReduceTasks(0);
      
      job.setInputFormatClass(TextInputFormat.class);
      job.setOutputFormatClass(TextOutputFormat.class);
      
      FileInputFormat.addInputPath(job, new Path(args[0]));
      FileOutputFormat.setOutputPath(job, new Path(args[1]));
      
      System.out.println(job.waitForCompletion(true));
      
  }
}

