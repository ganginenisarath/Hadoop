package com.eng.weblogProject;

import java.io.IOException;
//import java.util.StringTokenizer;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WeblogMapper extends
		Mapper<LongWritable, Text, Text, IntWritable> {
	private Text ip = new Text();
	private final static IntWritable one = new IntWritable(1);
	
	protected void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		String line = value.toString();
		StringTokenizer iptoken = new StringTokenizer(line," ");  

			 ip.set(iptoken.nextToken());
			context.write(ip, one);
		  //}
	}
}
